package application;
import java.util.Scanner;

public class BankApplication {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BankingService bankingService = new BankingService();

        System.out.println("Welcome to the Banking Application");

        boolean running = true;
        while (running) {
            System.out.println("\nChoose an option:");
            System.out.println("1. Create Account");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Account Summary");
            System.out.println("5. Exit");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    createAccount(scanner, bankingService);
                    break;
                case 2:
                    deposit(scanner, bankingService);
                    break;
                case 3:
                    withdraw(scanner, bankingService);
                    break;
                case 4:
                    accountSummary(scanner, bankingService);
                    break;
                case 5:
                    running = false;
                    System.out.println("Thank you for using the Banking Application.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }

    private static void createAccount(Scanner scanner, BankingService bankingService) {
        System.out.println("Enter username:");
        String username = scanner.nextLine();

        System.out.println("Enter email:");
        String email = scanner.nextLine();

        System.out.println("Enter phone number:");
        String phoneNumber = scanner.nextLine();

        System.out.println("Enter account number:");
        String accountNumber = scanner.nextLine();

        System.out.println("Enter address:");
        String address = scanner.nextLine();

        System.out.println("Enter PAN number:");
        String panNumber = scanner.nextLine();

        System.out.println("Choose account type (1 for Savings, 2 for Current):");
        int accountType = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        if (accountType == 1) {
            System.out.println("Enter initial balance for Savings Account:");
            double balance = scanner.nextDouble();
            scanner.nextLine();  // Consume newline

            SavingsAccount savingsAccount = new SavingsAccount(username, email, phoneNumber, accountNumber, address, panNumber, balance);
            bankingService.createUser(savingsAccount);
            System.out.println("Savings account created successfully.");
        } else if (accountType == 2) {
            System.out.println("Enter initial balance for Current Account:");
            double balance = scanner.nextDouble();
            scanner.nextLine();  // Consume newline

            System.out.println("Enter overdraft limit:");
            double overdraftLimit = scanner.nextDouble();
            scanner.nextLine();  // Consume newline

            CurrentAccount currentAccount = new CurrentAccount(username, email, phoneNumber, accountNumber, address, panNumber, balance, overdraftLimit);
            bankingService.createUser(currentAccount);
            System.out.println("Current account created successfully.");
        } else {
            System.out.println("Invalid account type. Account not created.");
        }
    }

    private static void deposit(Scanner scanner, BankingService bankingService) {
        System.out.println("Enter account number:");
        String accountNumber = scanner.nextLine();

        System.out.println("Enter deposit amount:");
        double amount = scanner.nextDouble();
        scanner.nextLine();  // Consume newline

        bankingService.depositSavings(accountNumber, amount);
    }

    private static void withdraw(Scanner scanner, BankingService bankingService) {
        System.out.println("Enter account number:");
        String accountNumber = scanner.nextLine();

        System.out.println("Enter withdrawal amount:");
        double amount = scanner.nextDouble();
        scanner.nextLine();  // Consume newline

        bankingService.withdrawSavings(accountNumber, amount);
    }

    private static void accountSummary(Scanner scanner, BankingService bankingService) {
        System.out.println("Enter account number:");
        String accountNumber = scanner.nextLine();

        bankingService.showAccountSummary(accountNumber);
    }
}
