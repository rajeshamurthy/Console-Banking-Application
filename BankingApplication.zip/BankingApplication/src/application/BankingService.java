package application;
import java.sql.*;

public class BankingService {

    public void createUser(User user) {
        String sql = "INSERT INTO UserDetails (username, email, phoneNumber, accountNumber, address, panNumber) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getEmail());
            pstmt.setString(3, user.getPhoneNumber());
            pstmt.setString(4, user.getAccountNumber());
            pstmt.setString(5, user.getAddress());
            pstmt.setString(6, user.getPanNumber());
            pstmt.executeUpdate();

            System.out.println("User account created successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void depositSavings(String accountNumber, double amount) {
        String sql = "UPDATE SavingsAccount SET balance = balance + ? WHERE userID = (SELECT userID FROM UserDetails WHERE accountNumber = ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setDouble(1, amount);
            pstmt.setString(2, accountNumber);
            pstmt.executeUpdate();
            System.out.println("Deposit successful.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void withdrawSavings(String accountNumber, double amount) {
        String sql = "UPDATE SavingsAccount SET balance = balance - ? WHERE userID = (SELECT userID FROM UserDetails WHERE accountNumber = ?) AND balance >= ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setDouble(1, amount);
            pstmt.setString(2, accountNumber);
            pstmt.setDouble(3, amount);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Withdrawal successful.");
            } else {
                System.out.println("Insufficient balance.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void showAccountSummary(String accountNumber) {
        String sql = "SELECT * FROM UserDetails WHERE accountNumber = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, accountNumber);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("Account Summary:");
                System.out.println("Username: " + rs.getString("username"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Phone Number: " + rs.getString("phoneNumber"));
                System.out.println("Account Number: " + rs.getString("accountNumber"));
                System.out.println("Address: " + rs.getString("address"));
                System.out.println("PAN Number: " + rs.getString("panNumber"));
            } else {
                System.out.println("Account not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
