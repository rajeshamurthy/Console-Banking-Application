package application;
public class SavingsAccount extends User {
    private double balance;

    public SavingsAccount(String username, String email, String phoneNumber, String accountNumber, String address, String panNumber, double balance) {
        super(username, email, phoneNumber, accountNumber, address, panNumber);
        this.balance = balance;
    }

    public void deposit(double amount) {
        balance += amount;
        System.out.println("Deposited: " + amount);
    }

    public void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawn: " + amount);
        } else {
            System.out.println("Insufficient balance.");
        }
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}
